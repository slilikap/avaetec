modify, publish, use, compile, sell, or distribute this software,
either in source code form or as a compiled binary, for any purpose,
commercial or non-commercial, and by any means.
Description: UNKNOWN
Platform: UNKNOWN
Classifier: Development Status :: 5 - Production/Stable
Classifier: Intended Audience :: Developers
Classifier: Operating System :: OS Independent
Classifier: Operating System :: Microsoft :: Windows
Classifier: Programming Language :: Python :: 2.7
Classifier: Topic :: Utilities
