from __future__ import absolute_import
# Copyright (c) 2010-2015 openpyxl


from .chart import Chart


class PieChart(Chart):

    TYPE = "pieChart"
