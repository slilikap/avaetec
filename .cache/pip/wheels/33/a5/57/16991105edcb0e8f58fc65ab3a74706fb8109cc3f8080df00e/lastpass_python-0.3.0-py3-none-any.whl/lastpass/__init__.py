from .vault import Vault
from .exceptions import *

__version__ = '0.3.0'

# lastpass-ruby's version
VERSION = '1.5.0'
